@echo off
echo Launching RCM Dashboard...
start "" "%~dp0dashboard.html"
exit
