1. Double-click Launch.bat (Windows) or Launch.command (Mac).
2. Fill out the 30-day offline trial registration.
3. Enjoy the RCM Dashboard!